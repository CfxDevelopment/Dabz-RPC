Config = {
    DiscordAppID = 11111111111111, -- discord bot app id https://discord.com/developers/docs/intro
    AppBigAssetID = 'dabz_development',
    AppBigAssetText = 'dabz_development',
    AppSmallAssetID = 'dabz_development',
    AppSmallAssetText = 'HELLO GUYS',
    FirstButtonPlaceholder = 'DABZ SCRIPTS',
    FirstButtonLink = 'https://discord.gg/cfxdev',
    SecondButtonPlaceholder = 'Discord',
    SecondButtonLink = 'https://discord.gg/cfxdev',

    UpdateEvery = 60000, -- In ms. (60000ms = 1 minute)
    Template = '{Citizens} | ID: {ID} | NAME: {NAME}' -- {NAME}, {ID}, {Citizens}
}
