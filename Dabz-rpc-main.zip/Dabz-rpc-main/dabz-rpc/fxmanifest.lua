fx_version 'cerulean'
game 'gta5'

author 'DABZ DEVELOPMENT'
description 'Discord Presence'
version '1.0.0'

shared_script 'shared/config.lua'
server_script 'server/server.lua'
client_script 'client/client.lua'
