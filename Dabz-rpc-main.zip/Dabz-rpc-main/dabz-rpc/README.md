:wave: Hey WELCOME TO DABZ DISCORD PRESENCE SHOWCASE

A SCRIPT THAT ALLOWS YOUR PLAYING SERVER STATUS .. !!

# Features :star:

   [ FREE ]
   
>. 2 Linkable Buttons

>. Customizable

>. Can add AppBigAssetID and  AppSmallAssetID

>. Playtime

>. show PLAYER ID , PLAYER NAME , PLAYERS

>. Update every 1 mins 


# Download & Installation

Download - DABZ DISCORD PRESENCE

DRAG TO FILE

ENSURE 


# INSTALLATION

AFTER DOWLOADING DABZ DISCORD RPC
---------
. Go to discord developer portal - https://discord.com/developers/applications

. Click on the "New Application" button.

. Enter a name and confirm the pop-up window by clicking the "Create" button.

. After creating it go to general information , in there copy APPLICATION ID

. Ater copying APPLICATION ID add it to shared/config.lua ,  DiscordAppID = [ add the copied id there ]

. Ater then go to  rich-presence , there art assets , there add image , add your image there

. And copy the add image name , then add it to   AppBigAssetText &  AppSmallAssetText



# IMAGE :star:
https://cdn.discordapp.com/attachments/1090915547455160343/1153567119636693042/image.png

# Dabz DEVELOPMENT DISCORD 

DISCORD -  https://discord.gg/cfxdev
